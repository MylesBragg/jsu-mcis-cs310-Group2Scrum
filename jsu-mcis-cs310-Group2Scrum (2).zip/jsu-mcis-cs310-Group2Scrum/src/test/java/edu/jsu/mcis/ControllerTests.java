package edu.jsu.mcis;

import org.junit.*;
import static org.junit.Assert.*;

import java.util.*;

public class ControllerTests
{
	
}
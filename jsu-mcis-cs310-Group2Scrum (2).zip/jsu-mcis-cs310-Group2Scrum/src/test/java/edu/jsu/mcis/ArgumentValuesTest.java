package edu.jsu.mcis;

import org.junit.*;
import static org.junit.Assert.*;

public class ArgumentValuesTest 
{
private ArgumentValues v;

	@Before
	public void testCreateInstanceofArgValues()
	{
		v = new ArgumentValues();
	}

	@Test
	public void testaddNametoValues()
	{
		v.setName("length");
		//v.addValueArgument("length", "7");
		assertEquals(v.getName(0), "length");
	}	
	@Test
	public void testGetValuefromValues()
	{
		v.setName("length");
		v.addValueArgument("length", "7");
		assertEquals(7, v.getValueArgument("length", "integer"));
	}
	@Test
	public void testGetValueBooleanArgument()
	{
		v.setName("rainy");
		v.addValueArgument("rainy", "true");
		assertEquals(true, v.getValueArgument("rainy", "boolean"));
	}
	@Test
	public void testGetValueFloatArgument()
	{
		v.setName("bathrooms");
		v.addValueArgument("bathrooms", "3.5");
		assertEquals(3.5f, v.getValueArgument("bathrooms", "float"));
	}
	@Test
	public void testGetValueOptionalArgument()
	{
		v.setName("--closets");
		v.addValueArgument("--closets", "6");
		assertEquals("6", v.getValueArgument("--closets", "optional"));
	}
	//@Test
	public void testMultiple()
	{
		v.setName("length");
		v.setName("width");
		v.setName("height");
		v.addValueArgument("length", "7");
		//assertEquals(7, v.getValueArgument("length", "integer"));
		v.addValueArgument("width", "4");
		//assertEquals(4, v.getValueArgument("width", "integer"));
		v.addValueArgument("height", "6");
		//assertEquals(6, v.getValueArgument("height", "integer"));
	}
	
	
	@Test
	public void testAddHelpArgument() {
		v.addHelpArgument("length", "Please add length as a whole number.");
		assertEquals("Please add length as a whole number.", v.getHelpArgument("length"));
	}
	
	@Test
	public void testAddMultipleHelpArguments() {
		v.addHelpArgument("length", "Please add length as a whole number.");
		assertEquals("Please add length as a whole number.", v.getHelpArgument("length"));
		v.addHelpArgument("width", "Please add width as a whole number.");
		assertEquals("Please add width as a whole number.", v.getHelpArgument("width"));
	}
	@Test
	public void testAddDataTypeArgument() {
		v.addDataTypeArgument("length", "integer");
		assertEquals("integer", v.getDataTypeArgument("length"));
	}
	@Test
	public void testAddMultipleDataTypeArguments() {
		v.addDataTypeArgument("length", "integer");
		assertEquals("integer", v.getDataTypeArgument("length"));
		v.addDataTypeArgument("width", "float");
		assertEquals("float", v.getDataTypeArgument("width"));
	}
}